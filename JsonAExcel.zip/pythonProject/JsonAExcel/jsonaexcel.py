import pandas as pd
import json
import datetime

path = r'employees.json'
plus_month = datetime.date.today().strftime("%B")
plus_year = datetime.date.today().strftime("%Y")

salario = []
edad = []
nombre = []
genero = []
proyecto = []
email = []

with open(path, 'r') as file:
    data = json.load(file)

    for persona in data:
        if persona['proyect'] != "GRONK":
            salario_persona = float(persona['salary'][1:].replace(",", ""))

            if persona['age'] < 30:
                salario_persona = salario_persona + salario_persona * 0.1

            salario_persona = f"{salario_persona}€"

            salario.append(salario_persona)
            edad.append(persona['age'])
            nombre.append(persona['name'])
            genero.append(persona['gender'])
            proyecto.append(persona['proyect'])
            email.append(persona['email'])

df = pd.DataFrame(
    {'Nombre': nombre, 'Edad': edad, 'Género': genero, 'Proyecto': proyecto, 'Email': email, 'Salario': salario})

name_excel = "pagos-empleados-" + plus_month + "-" + plus_year
df.to_excel(name_excel + '.xlsx')


""" - Empleados menores de 30 años +10% salario
    - Los empleados del proyecto 'GRONK' no aparecen
    - Cambiar dolar por euro y poner al final
    - El excel se llamará "pagos-empleados-mes-año' donde mes y año actuales
    - Entrega el link de tu repositorio en github."""
